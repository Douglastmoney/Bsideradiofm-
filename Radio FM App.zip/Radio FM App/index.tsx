'use client'

import { useState, useRef } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Volume2, VolumeX, Facebook, MessageCircle, Mail } from 'lucide-react'
import { Slider } from "@/components/ui/slider"

export default function Component() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(1)
  const [isMuted, setIsMuted] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0]
    setVolume(newVolume)
    if (audioRef.current) {
      audioRef.current.volume = newVolume
    }
  }

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-700 to-indigo-900 p-4">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="absolute inset-0 flex items-center justify-center text-white text-9xl font-bold opacity-10">
          bsideradiofm
        </div>
      </div>
      <Card className="w-full max-w-md mx-auto bg-white/10 backdrop-blur-md border-none text-white">
        <CardHeader>
          <CardTitle className="text-center text-3xl font-bold">Radio FM Player</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <audio
            ref={audioRef}
            src="https://stream.zeno.fm/fu9muxvskm0uv"
            preload="metadata"
          />
          
          <div className="space-y-4">
            <Button 
              className="w-full text-lg h-12 bg-gradient-to-r from-pink-500 to-yellow-500 hover:from-pink-600 hover:to-yellow-600 text-white font-bold" 
              onClick={togglePlay}
            >
              {isPlaying ? 'Pause' : 'Play'}
            </Button>
            
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleMute}
                className="text-white hover:text-yellow-300"
              >
                {isMuted ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}
              </Button>
              <Slider
                value={[volume]}
                max={1}
                step={0.01}
                onValueChange={handleVolumeChange}
                className="flex-1"
              />
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4 pt-4">
            <Button
              variant="outline"
              className="flex gap-2 bg-blue-600 hover:bg-blue-700 text-white border-none"
              asChild
            >
              <a 
                href="https://www.facebook.com/profile.php?id=100094210853562"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Facebook className="h-4 w-4" />
                Facebook
              </a>
            </Button>
            <Button
              variant="outline"
              className="flex gap-2 bg-green-600 hover:bg-green-700 text-white border-none"
              asChild
            >
              <a 
                href="https://whatsapp.com/channel/0029VaDHuKk0gcfNyAWQBP1o"
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="h-4 w-4" />
                WhatsApp
              </a>
            </Button>
            <Button
              variant="outline"
              className="flex gap-2 bg-red-600 hover:bg-red-700 text-white border-none"
              asChild
            >
              <a 
                href="mailto:bsideradioam@gmail.com"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Mail className="h-4 w-4" />
                Email
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}