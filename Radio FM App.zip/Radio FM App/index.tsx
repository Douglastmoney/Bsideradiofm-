'use client'

import { useState, useRef } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Volume2, VolumeX, Facebook, MessageCircle } from 'lucide-react'
import { Slider } from "@/components/ui/slider"

export default function Component() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(1)
  const [isMuted, setIsMuted] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0]
    setVolume(newVolume)
    if (audioRef.current) {
      audioRef.current.volume = newVolume
    }
  }

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Radio FM Player</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <audio
          ref={audioRef}
          src="https://stream.zeno.fm/fu9muxvskm0uv"
          preload="metadata"
        />
        
        <div className="space-y-4">
          <Button 
            className="w-full text-lg h-12" 
            variant="default"
            onClick={togglePlay}
          >
            {isPlaying ? 'Pause' : 'Play'}
          </Button>
          
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMute}
            >
              {isMuted ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}
            </Button>
            <Slider
              value={[volume]}
              max={1}
              step={0.01}
              onValueChange={handleVolumeChange}
              className="flex-1"
            />
          </div>
        </div>

        <div className="flex justify-center gap-4 pt-4">
          <Button
            variant="outline"
            className="flex gap-2"
            asChild
          >
            <a 
              href="https://www.facebook.com/profile.php?id=100094210853562"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Facebook className="h-4 w-4" />
              Facebook
            </a>
          </Button>
          <Button
            variant="outline"
            className="flex gap-2"
            asChild
          >
            <a 
              href="https://whatsapp.com/channel/0029VaDHuKk0gcfNyAWQBP1o"
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle className="h-4 w-4" />
              WhatsApp
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}